# 🧬 curvality-fusion-validation

This repository provides a reproducible Bayesian validation of the **Curvality collapse-driven fusion model**, comparing it to standard quantum tunneling using real experimental D–T fusion cross-section data.

---

## 📜 Contents

| File | Description |
|------|-------------|
| `Curvality_Fusion_Validation.ipynb` | Google Colab-ready notebook with full model, equations, and sampling |
| `DT_Fusion_Cross_Section.csv` | Experimental cross-section data (deuterium–tritium fusion) |
| `Curvality_Fusion_Trace.pkl` | Posterior samples from Bayesian inference |
| `curvality_fusion_fit.png` | Plot comparing model fit to experimental data |
| `README.md` | This file |
| `LICENSE` | MIT license |

---

## 🔧 Quick Start

You can run the full Bayesian model in **Google Colab** (no local setup required):

1. Click [here to open Colab](https://colab.research.google.com/)
2. Upload the file `Curvality_Fusion_Validation.ipynb`
3. Upload the `DT_Fusion_Cross_Section.csv` file when prompted
4. Run all cells to:
   - Fit the Curvality model to the real fusion data
   - Extract posterior parameter distributions
   - Compare against standard tunneling

---

## 📐 Theoretical Background

The Curvality framework introduces collapse-assisted fusion dynamics:

> $$ P_{fusion}^{Curvality}(E) = \eta(R, S) \cdot \left(1 - e^{-E/T_c} \right) $$

This emerges from a modified Lagrangian:

> $$ \mathcal{L} = \frac{1}{2}(\partial_\mu \phi)^2 - \frac{1}{2}m^2 \phi^2 - \frac{\lambda}{4} \phi^4 + \alpha R \phi + \beta S \phi - \frac{\chi}{6}f(R, S) $$

Where:
- \( R \): local spacetime curvature
- \( S \): local entropy gradient
- \( \chi \): collapse coupling
- \( T_c \): critical energy threshold

---

## 📊 What It Proves

- Validates collapse-driven fusion using real D–T data  
- Matches observed cross-sections without invoking tunneling  
- Provides posterior distributions of fit parameters  
- Ready for reproduction, extension, and peer review

---

## 🔁 Reproducibility

To repeat or extend the results:

```bash
git clone https://github.com/YOUR_USERNAME/curvality-fusion-validation.git
cd curvality-fusion-validation
```

Run the notebook in:
- [Google Colab](https://colab.research.google.com/)
- Jupyter Lab
- Any Python environment with `pymc`, `matplotlib`, and `pandas`

---

## 📖 Citation

If using this work in academic publications, cite as:

```
Brett, J. (2025). Collapse-driven Fusion in the Curvality Framework. GitHub. https://github.com/YOUR_USERNAME/curvality-fusion-validation
```

(Replace with DOI once published via Zenodo.)