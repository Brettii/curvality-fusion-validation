# Curvality Fusion Validation

This repository provides a reproducible Bayesian analysis comparing standard quantum tunneling with the Curvality collapse-driven fusion model.

## Included

- `Curvality_Fusion_Validation.ipynb`: Full Colab notebook to reproduce results
- `DT_Fusion_Cross_Section.csv`: Real D-T fusion cross-section data
- `curvality_fusion_fit.png`: Generated plot of model fit
- `Curvality_Fusion_Trace.pkl`: Posterior samples for further analysis

## Theory

The Curvality model modifies the fusion probability using a collapse field term derived from the unified Lagrangian:

```
L = 1/2 (∂_μϕ)^2 - 1/2 m²ϕ² - λ/4 ϕ⁴ + αRϕ + βSϕ - χ/6 f(R, S)
```

This leads to a modified fusion probability:
```
P_fusion^Curvality(E, R, S) = η(χ, R, S) · (1 - exp(−E / T_c))
```

## License

MIT